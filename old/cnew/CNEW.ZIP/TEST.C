int p;
char res;

void test ( void )
{
  res = *(char *)&p;
}

